export default function LoggingIn(props) {
    return (
        <>
            <p>Logging you in... Please wait</p>
        </>
    );
}